import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {getallvendor} from '../getallvendor.service'
//import { GlobalService } from '../global.service';
import {TokenParams} from '../TokenParams';
import { GlobalService } from '../global.service';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {
      public token:TokenParams;
  constructor(
    private gService: GlobalService,
    private router: Router
   
  ) { }
  

  ngOnInit() {
    
    if(!this.gService.isUserSignIn())
    {
 this.router.navigate(['/'])
 
    }
    
    // else
    // alert("Logged in successfully");
      // if(!this.gService.isUserSignIn()) {
      //   this.router.navigate(['/']);
      // }
  }

}
