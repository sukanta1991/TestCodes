import { Component, OnInit } from '@angular/core';
import { Router , ActivatedRoute, Params} from '@angular/router';
import { Http, Response } from '@angular/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {product} from '../product';
import {ProductService} from './product.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';
import {ProductModel} from './productmodel'


@Component({
  selector: 'app-view-productlist',
  templateUrl: './view-productlist.component.html',
  styleUrls: ['./view-productlist.component.css']
})
export class ViewProductlistComponent implements OnInit {
  productList: product[];
  productView: product[];
  pModel: any;
  pId:number;
   pModel2 =new ProductModel();
   errorMessage:string;
   errorMessageBody:string;

 
  
  constructor(private _router:Router ,private datePipe: DatePipe,private spinner: NgxSpinnerService,private route: ActivatedRoute, private productService: ProductService) { }

  ngOnInit() {
    this.spinner.show();
    setTimeout(() => {
      this.fetchProductList();
        /** spinner ends after 5 seconds */
        this.spinner.hide();
    }, 3000);
   
  }

  fetchProductList(){
    this.productService.getProductList().subscribe(data => {
      this.productList = data;
      this.productList.map(x=>{
        x["startdates"] = new Date(x.startdate).toDateString();
        x["enddates"] = new Date(x.enddate).toDateString();
      })
     this.productView = JSON.parse(JSON.stringify(data));
  console.log(this.productView);
  })
  }
  onKey(event: any){
    if(event.target.value)
    {
      this.productView = this.productList.filter(x=>
        {
          return x.productname.toLowerCase().includes(event.target.value.trim());
        });
    }
    else
    {
      this.productView = JSON.parse(JSON.stringify(this.productList));
    }
  }

  updateProduct(){
    this.pModel2.serviceId=-1
    this.pModel2.basePrice=this.pModel.baseprice
    this.pModel2.active=this.pModel.isactive;
    this.pModel2.description=this.pModel.description;
    this.pModel2.endDate=this.pModel.enddate;
    this.pModel2.startDate=this.pModel.startdate;
    this.pModel2.id=this.pModel.id;
    this.pModel2.imageUrl=this.pModel.imageurl;
    this.pModel2.productName=this.pModel.productname;
    //console.log(this.pModel.productname);
    this.productService.updateProduct(this.pModel2).subscribe(
     
    successResponse => {
      alert('Product Updated Successfully');
      this._router.navigate(['/admin/home']);
    },
    errorResponse   => {
      alert('There was an Error while updating product,please enter correct details');
      this.errorMessage = errorResponse.statusText;
      this.errorMessageBody = errorResponse._body;
    }
    )
  }


  deleteProduct(id:number, name:string){
    if(confirm("Do you want to delete service " + name))
    this.productService.deleteProduct(id).subscribe(data =>{
      console.log(data);
      this.fetchProductList();
      alert("Product Deleted Successfully");
    })
  }

}