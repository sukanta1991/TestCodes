
// "active": true,
    // "basePrice": 0,
    // "description": "string",
    // "endDate": "2018-09-16T04:37:42.925Z",
    // "id": 0,
    // "imageUrl": "string",
 

export class ProductModel
{
    public id:number;
    public productName:string;
    public description:string;
    public active:boolean;
    public startDate:Date;
    public endDate:Date;
    public imageUrl:string;
    public basePrice:number;
    public serviceId?: number

}