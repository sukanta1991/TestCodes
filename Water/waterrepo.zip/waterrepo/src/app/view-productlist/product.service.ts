import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable, Subject } from 'rxjs';
import { map, catchError} from 'rxjs/operators';
import { product  } from '../product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:Http) { }
  private baseApiUri= "http://atserve-waterapp.ap-south-1.elasticbeanstalk.com/api/v1/product";
  private baseApiUriDelete="http://atserve-waterapp.ap-south-1.elasticbeanstalk.com/api/v1/product/";
  private NotAttachedbaseApi="http://atserve-waterapp.ap-south-1.elasticbeanstalk.com/api/v1/vendor/";
  getProductList() :Observable<any> {
    let headers = new Headers({'Content-Type': 'application/json'});
    let options = new RequestOptions({ headers: headers });
    return this.http.get(this.baseApiUri, options)
        .pipe(map((response: Response) => <any>response.json()),
        catchError(this.handleError));
  }

  getNotAttachedProductList(vendorid):Observable<any>
  {
    let headers = new Headers({'Content-Type': 'application/json'});
    let options = new RequestOptions({ headers: headers });
    return this.http.get(this.NotAttachedbaseApi+vendorid+"/notattachedproduct", options)
        .pipe(map((response: Response) => <any>response.json()),
        catchError(this.handleError));

  }

  private handleError(error: any) {
    let errMsg = (error.Message) ? error.Message :
        error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg);
    return Observable.throw(errMsg);
  }

  updateProduct( model): Observable<any> {
    //delete model['serviceId'];
    // let headers = new Headers({ 'Content-Type': 'application/json' });
    // let options = new RequestOptions({ headers: headers });
    let body = model;
    return this.http.put(this.baseApiUri + '/update', body)
        .pipe(map((response: Response) => response.status == 200 ? 1 : response.status),
        catchError(this.handleError));

}

deleteProduct(id: number): Observable<any> {
      
  // let options = new RequestOptions({ headers: headers });
   return this.http.delete(this.baseApiUriDelete + id+"/delete")
       .pipe(map((response: Response) =>response.status == 200 ? 1 : response.status),
       catchError(this.handleError1));
      
      
}

private handleError1(error:any)
{
  let errMsg = (error.Message) ? error.Message :
        error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg);
   
    alert("The product is mapped to vendor,please delete from Vendor list");
    return Observable.throw(errMsg);

}




}
