import { Component, OnInit } from '@angular/core';
import {vendordetails} from './vendordetails';
import {ProductService} from '../view-productlist/product.service';
import {getallvendor} from '../getallvendor.service';
import { product } from '../product';
import { Router } from '@angular/router';
import { GlobalService } from '../global.service';


@Component({
  selector: 'app-product-to-vendor',
  templateUrl: './product-to-vendor.component.html',
  styleUrls: ['./product-to-vendor.component.css']
})
export class ProductToVendorComponent implements OnInit {
    public vendor:vendordetails;
    public vendors:vendordetails[];
    model:any ={};
    productList: product[];
    NotAttachedProductList:product[];
  productView: product[];
  NotAttachedProductView:product[];
  errorMessage:any;
  errorMessageBody:any;
  Access:any;

  

  constructor(private _gservice:GlobalService, private _getvendorlist:getallvendor,private _productlist:ProductService,
    private router:Router) {
    this.Access=this._getvendorlist.AccessToken;

   }

  ngOnInit() {
   if(this._gservice.isUserSignIn())
   {
   this.getVendorlist();
    this.fetchProductList();
   }
    
  }

  getVendorlist()
  {
    this._getvendorlist.getvendorList().subscribe(data =>{
      this.vendors = JSON.parse(JSON.stringify(data));
    })

  }
  fetchProductList(){
    this._productlist.getProductList().subscribe(data => {
      this.productList = data;
      this.productList.map(x=>{
        x["startdates"] = new Date(x.startdate).toDateString();
        x["enddates"] = new Date(x.enddate).toDateString();
      })
     this.productView = JSON.parse(JSON.stringify(data));
  })
  }
  myFunction1(value)
  {
   this.model.vendorid=parseInt(value);
   if(this.model.vendorid)
   {
     this.fetchNotAttachedProductList();
   }
   
  }

  fetchNotAttachedProductList(){
    this._productlist.getNotAttachedProductList(this.model.vendorid).subscribe(data => {
      this.NotAttachedProductList = data;
      this.NotAttachedProductList.map(x=>{
        x["startdates"] = new Date(x.startdate).toDateString();
        x["enddates"] = new Date(x.enddate).toDateString();
      })
     this.NotAttachedProductView = JSON.parse(JSON.stringify(data));
  })
  }

 
  myFunction2(value)
  {
    this.model.productid=parseInt(value);

  }

  onSubmit()
  {
    console.log(this.model);
    this._getvendorlist.MapProductToVendor(this.model).subscribe(
      successResponse => {
        alert('Product mapped Successfully');
        this.router.navigate(['/admin/home']);
      },
      errorResponse   => {
        alert('There was an Error while mapping product');
        this.errorMessage = errorResponse.statusText;
        this.errorMessageBody = errorResponse._body;
      }
    )
    
  }

}
