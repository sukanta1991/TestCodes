export class addressSet
{

   public  id :number;
       public lift: boolean;
      public  primise: string;
       public sublocalitylevel2: string;
        public sublocalitylevel1: string;
        public locality: string;
       public administrativearealevel2: string;
       public administrativearealevel1: string;
       public country: string;
        public pincode: string;
        public addresstype: string;
        public primaryaddress: boolean;
         public fullAddress: string;
       public addressname: string;
       public lat: number;
        public lng: number;
}