import {addressSet} from './addressSet';
export class vendordetails
{

     public id:number;
    public firstName: string;
    public lastName: string;
    public contactNumber: number;
     public companyName: string;
    public email: string;
    public website: string;
    public addressSet:addressSet[];

}