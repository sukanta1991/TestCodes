

export class producttovendor
{
    public availablestock:number;
    public disabled:boolean;
    public enddate:Date;
    public listprice:number;
    public productid:number;
    public qualitysalelimit:number;
    public startdate:Date;
    public vendorid:number;

}