import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions ,HttpModule } from '@angular/http';
import {HttpHeaders} from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { map, catchError} from 'rxjs/operators';
import { TokenParams } from './TokenParams';
import { GlobalService } from './global.service';

@Injectable({
  providedIn: 'root'
})

export class getallvendor {
 
    AccessToken:string="";
    vendorid:number;
    

    constructor(private http:Http ,private _gservice:GlobalService) { }
    private baseApiUri= "http://atserve-waterapp.ap-south-1.elasticbeanstalk.com/api/v1/vendor";
    private mapUri="http://atserve-waterapp.ap-south-1.elasticbeanstalk.com/api/v1/mapvendorproduct";
    private TokenApi="http://atserve-waterapp.ap-south-1.elasticbeanstalk.com/api/v1/admin/login";
    private productvendorApi ="http://atserve-waterapp.ap-south-1.elasticbeanstalk.com/api/v1/vendor/product?vendorId="

   login(Username:string,Password:string) :Observable<TokenParams>
   {
    //let headers = new Headers({ 'Content-Type': 'application/json' });
    //{ 'Content-Type': 'application/x-www-form-urlencoded'}
    let headersforTokenAPI = new Headers();
    let key="Authorization";
    let value="Basic dGVzdGp3dGNsaWVudGlkOlhZN2ttem9OemwxMDA=";
    headersforTokenAPI.append(key,value);
 
    let options = new RequestOptions({ headers: headersforTokenAPI });
    //var data= "grant_type=password&username="+Username+"&password="+Password;
  let body ={
    "password":Password,
    "username":Username
}

    return this.http.post(this.TokenApi,body,options)
    .pipe(map((response: Response) => <any>response.json()),
    catchError(this.handleError));

   }

   //Get all Product of Vendor

   getallProductofvendor(vendorid)
   {
    let options=this.getheaders();
    return this.http.get(this.productvendorApi+vendorid, options)
    .pipe(map((response: Response) => <any>response.json()),
    catchError(this.handleError));
   }



    getvendorList():Observable<any> {

        if(this._gservice.isUserSignIn())
        {
        let headers = new Headers();
    //     headers.append('Accept', 'application/json');
    // headers.append('Access-Control-Allow-Origin', '*');
    // headers.append('Access-Control-Allow-Headers', '*');
        let key="Authorization";
        let val =this._gservice.findacessvalue(this._gservice.getservicedata());
        let value="Bearer "+val;
        headers.append(key,value);
        let options = new RequestOptions({ headers: headers });
        return this.http.get(this.baseApiUri, options)
        .pipe(map((response: Response) => <any>response.json()),
        catchError(this.handleError));
        }
    }



MapProductToVendor(model): Observable<any>{
let body=(model);
console.log(JSON.stringify(body)+"body hitted");
let options= this.getheaders();
return this.http.post(this.mapUri,body,options);

}

    private handleError(error: any) {
        console.log("err");
        let errMsg = (error.Message) ? error.Message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg);
        console.log("oops got error");
        return Observable.throw(errMsg);
      }

      private getheaders()
      {
        let headers = new Headers();
        //     headers.append('Accept', 'application/json');
        // headers.append('Access-Control-Allow-Origin', '*');
        // headers.append('Access-Control-Allow-Headers', '*');
            let key="Authorization";
            let value="Bearer "+this.AccessToken;
            headers.append(key,value);
            let options = new RequestOptions({ headers: headers });
            return options
      }
  

}