import { Injectable, Inject } from '@angular/core';
import {SESSION_STORAGE, WebStorageService} from 'angular-webstorage-service';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {
  serviceData: string; 
  constructor(@Inject(SESSION_STORAGE) private storage: WebStorageService) { }

  getservicedata():string
  {
    return this.serviceData;
  }

  setservicedata(key):void
  {
    this.serviceData=key;
  }

  setUserSignIn(key,val): void {
   
    this.setSession(key, val);
  }


  setUserSignOut(): void {
   this.storage.remove(this.getservicedata());
  }

  setSession(key, val): void {
    this.storage.set(key, val);
  }
  findacessvalue(key):string
  {
    return this.storage.get(key);
  }

  isUserSignIn() {
    let key = this.getservicedata();
    let val = this.storage.get(key);

    if (val != ''){
      return true;
    }
    else{
      return false;
    }
  }

}
