import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import {getservice} from '../get-all-service/getservice.service';
import { Router } from '@angular/router';
import {HttpClient,HttpHeaders} from '@angular/common/http'

import { Http,Response, RequestOptions, Headers } from '@angular/http';

@Component({
  selector: 'app-new-service',
  templateUrl: './new-service.component.html',
  styleUrls: ['./new-service.component.css']
})
export class NewServiceComponent implements OnInit {
  private serviceactiveflag: boolean = true;
  model: any = {};
  private errorMessage:string;
  private errorMessageBody:string;
  selectedFile:File=null;

 private baseApiUrl="http://atserve-waterapp.ap-south-1.elasticbeanstalk.com/api/v1/product/upload";


  constructor(private http:HttpClient, private _getservice:getservice,private router:Router ) { }

  public onserviceactiveflagchecked(value:boolean){
    this.serviceactiveflag = value;
  }

  onFileSelected(event)
  {
  this.selectedFile=<File>event.target.files[0];
  }

  onUpload()
  {
    const fd=new FormData();
    const HttpUploadOptions = {
      headers: new HttpHeaders({ "Content-Type": "multipart/form-data" })
    }

    fd.append('image',this.selectedFile,this.selectedFile.name)
    
  this.http.post(this.baseApiUrl,fd).subscribe(res=>{
    console.log(res);
  })
  }

  onSubmit() {
    this._getservice.postServiceList(this.model).subscribe(
      successResponse => {
        alert('Service Created Successfully');
        this.router.navigate(['/admin/home']);
      },
      errorResponse   => {
        alert('There was an Error while creating service');
        this.errorMessage = errorResponse.statusText;
        this.errorMessageBody = errorResponse._body;
      }
    );
  }
  
  

  ngOnInit() {
  }

}
