import { Component, OnInit } from '@angular/core';
import {vendordetails} from '../product-to-vendor/vendordetails';
import {ProductService} from '../view-productlist/product.service';
import {getallvendor} from '../getallvendor.service';
import { product } from '../product';
import { Router } from '@angular/router';




@Component({
  selector: 'app-show-vendor-product',
  templateUrl: './show-vendor-product.component.html',
  styleUrls: ['./show-vendor-product.component.css']
})
export class ShowVendorProductComponent implements OnInit {
  public vendor:vendordetails;
  public vendors:vendordetails[];
  public vendorid:number;
  public product:product;
  public products:product[];
  constructor(private _getvendorlist:getallvendor,private router:Router) { }

  ngOnInit() {
    this.getVendorlist();
  }
  getVendorlist()
  {
    this._getvendorlist.getvendorList().subscribe(data =>{
      this.vendors = JSON.parse(JSON.stringify(data));
    })

  }

  myFunction1(vendorid)
  {
  this.vendorid= parseInt(vendorid);
  }

  onShow()
{
  console.log(this.vendorid);
  this._getvendorlist.getallProductofvendor(this.vendorid).subscribe(data =>{
    this.products = JSON.parse(JSON.stringify(data));
  })
}
  

}
