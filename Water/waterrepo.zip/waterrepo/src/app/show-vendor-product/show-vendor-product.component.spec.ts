import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowVendorProductComponent } from './show-vendor-product.component';

describe('ShowVendorProductComponent', () => {
  let component: ShowVendorProductComponent;
  let fixture: ComponentFixture<ShowVendorProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowVendorProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowVendorProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
