export class product
{
 public id?:number;
 public productname?:string;
 public description?:string;
 public isactive?:boolean;
 public startdate:Date;
 public enddate:Date;
 public imageurl:string;
 public baseprice:number;
 public serviceId?: number


}